import { Component } from '@angular/core';

@Component({
  selector: 'app-spaces',
  templateUrl: './spaces.component.html',
  styleUrl: './spaces.component.scss',
})
export class SpacesComponent {
  ids: any;
  searchValue: any;

  ngOnInit() {
    this.searchValue = '';
    this.ids = [
      {
        id: 1,
        job: 'UI',
        salary: '20k to 30k',
        location: 'chennai',
        imgUrl: '',
        loadMore: false,
      },
      {
        id: 2,
        job: 'java',
        salary: '25k to 30k',
        location: 'banglore',
        imgUrl: '',
        loadMore: false,
      },
      {
        id: '3',
        job: 'Uipath',
        salary: '10k to 30k',
        location: 'karnataka',
        imgUrl: '',
        loadMore: false,
      },
      {
        id: 4,
        job: 'cloud',
        salary: '200k to 30k',
        location: 'noida',
        imgUrl: '',
        loadMore: false,
      },
      {
        id: '5',
        job: 'data',
        salary: '202k to 30k',
        location: 'andhra',
        imgUrl: '',
        loadMore: false,
      },
    ];
  }
}
