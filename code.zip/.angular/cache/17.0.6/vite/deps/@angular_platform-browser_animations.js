import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-AJFOUTFH.js";
import "./chunk-A2OFGU6H.js";
import "./chunk-WTLPC6HK.js";
import "./chunk-VV2WFPAY.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-DMWQ5VCX.js";
import "./chunk-OXCW2X5T.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
